var renderClass = "jp.ngt.rtm.render.MechanismPartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.ngtlib.renderer);
importPackage(Packages.jp.ngt.ngtlib.math);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	var modelName = par1.getConfig().getName();
	if(modelName.contains("shaft"))
	{
		main = renderer.registerParts(new Parts("shaft"));
	}
	else if(modelName.contains("pulley"))
	{
		main = renderer.registerParts(new Parts("shaft", "pulley"));
	}
	else
	{
		main = renderer.registerParts(new Parts("shaft", "gear1", "gear2"));
	}
}

function render(entity, pass, par3)
{
	GL11.glPushMatrix();

	if(pass == 0)
	{
		var rotation = renderer.getRotation(entity, Axis.POSITIVE_Y);
		GL11.glRotatef(rotation, 0.0, 1.0, 0.0);
		main.render(renderer);
	}

	GL11.glPopMatrix();
}
