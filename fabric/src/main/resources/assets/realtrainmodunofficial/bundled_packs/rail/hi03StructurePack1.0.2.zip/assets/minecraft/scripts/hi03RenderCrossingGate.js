var renderClass = 'jp.ngt.rtm.render.MachinePartsRenderer';
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
  main = renderer.registerParts(new Parts('body'));
  light1 = renderer.registerParts(new Parts('light1'));
  light2 = renderer.registerParts(new Parts('light2'));
  light3 = renderer.registerParts(new Parts('light3'));
  bar = renderer.registerParts(new Parts('bar'));
  bar2 = renderer.registerParts(new Parts('bar2'));
}

function render(entity, pass, par3)
{
  GL11.glPushMatrix();
  var light = renderer.getLightState(entity);
  var name = renderer.getModelName();
  var rotate = 85;
  var flipPos = -0.5303;
  if(name.contains("L") === true){
    rotate = rotate * -1;
    flipPos = flipPos * -1;
  }
  if(pass == 0)
  {
    main.render(renderer);
    light1.render(renderer);
    light2.render(renderer);
    light3.render(renderer);
    GL11.glPushMatrix();
    var move = renderer.getMovingCount(entity)*(rotate);
    var move2 = move * -1;

    renderer.rotate(move, 'Z', 0.0, 0.9056, 0.0);
    bar.render(renderer);
    GL11.glPopMatrix();

    GL11.glPushMatrix();
    renderer.rotate(move, 'Z', 0.0, 0.9056, 0.0);
    renderer.rotate(move2, 'Z', flipPos, 6.0287, 0.0);
    bar2.render(renderer);
    GL11.glPopMatrix();
    switch(light)
    {
		  case 0: light1.render(renderer);break;
		  case 1: light2.render(renderer);break;
    }
  }
  else if(pass == 2)
  {
		switch(light)
		{
		case 0: light2.render(renderer);break;
		case 1: light1.render(renderer);break;
		}
  }
  GL11.glPopMatrix();
}