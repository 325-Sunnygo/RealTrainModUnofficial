var renderClass = 'jp.ngt.rtm.render.MachinePartsRenderer';
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2) {
    main = renderer.registerParts(new Parts('obj1'));
    door = renderer.registerParts(new Parts('obj2'));
    windowMain = renderer.registerParts(new Parts('obj3'));
    windowDoor = renderer.registerParts(new Parts('obj4'));
}

function render(entity, pass, par3) {
    GL11.glPushMatrix();
    var light = renderer.getLightState(entity);
    var doorLength = 0.0;
    var doorSpeed = 0.0;
    var modelName = renderer.getModelName();
    var typeHalfblock = 0.0;
    if (modelName.contains("100") === true) {
        doorLength = 1.0;
        doorSpeed = 2.0;
    }
    if (modelName.contains("200") === true) {
        doorLength = 2.0;
        doorSpeed = 1.5;
    }
    if (modelName.contains("300") === true) {
        doorLength = 3.0;
        doorSpeed = 1.0;
    }
    if (modelName.contains("L") === true) {
        doorLength = doorLength * -1;
    }
    if (modelName.contains("HB") === true) {
        typeHalfblock = -0.5;
    }
    if (pass == 0) {
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0, typeHalfblock, 0.0);
        main.render(renderer);
        GL11.glPopMatrix();
      
        GL11.glPushMatrix();
        var move = renderer.getMovingCount(entity) * doorSpeed * (
            doorLength);
        if (doorLength > 0) {
            if (move > doorLength) {
                move = doorLength;
            }
        }
        else if (doorLength < 0) {
            if (move < doorLength) {
                move = doorLength;
            }
        }
        GL11.glTranslatef(move, typeHalfblock, 0.0);
        door.render(renderer);
        GL11.glPopMatrix();
    }
    else if (pass == 1) {
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0, typeHalfblock, 0.0);
        windowMain.render(renderer);
        GL11.glPopMatrix();
      
        GL11.glPushMatrix();
        var move = renderer.getMovingCount(entity) * doorSpeed * (
            doorLength);
        if (doorLength > 0) {
            if (move > doorLength) {
                move = doorLength;
            }
        }
        else if (doorLength < 0) {
            if (move < doorLength) {
                move = doorLength;
            }
        }
        GL11.glTranslatef(move, typeHalfblock, 0.0);
        windowDoor.render(renderer);
        GL11.glPopMatrix();
    }
    GL11.glPopMatrix();
}