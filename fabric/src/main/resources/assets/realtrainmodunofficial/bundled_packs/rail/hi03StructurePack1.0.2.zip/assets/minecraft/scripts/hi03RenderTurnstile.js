var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	main = renderer.registerParts(new Parts("body"));
	doorL = renderer.registerParts(new Parts("doorL"));
	doorR = renderer.registerParts(new Parts("doorR"));
}

function render(entity, pass, par3)
{
	GL11.glPushMatrix();

	if(pass == 0)
	{
		main.render(renderer);

		var state = renderer.getMovingCount(entity);
		if(state > 0.0)
		{
			doorL.render(renderer);
			doorR.render(renderer);
		}
		else
		{
			GL11.glPushMatrix();
			renderer.rotate(75.0, 'Y', -0.47, 0, -0.44);
			doorL.render(renderer);
			GL11.glPopMatrix();

			GL11.glPushMatrix();
			renderer.rotate(-75.0, 'Y', 0.32, 0, -0.44);
			doorR.render(renderer);
			GL11.glPopMatrix();
		}
	}

	GL11.glPopMatrix();
}
