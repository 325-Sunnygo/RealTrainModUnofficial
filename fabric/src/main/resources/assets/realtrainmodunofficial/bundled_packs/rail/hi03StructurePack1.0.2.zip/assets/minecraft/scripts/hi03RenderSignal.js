var renderClass = 'jp.ngt.rtm.render.MachinePartsRenderer';
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2) {
  main = renderer.registerParts(new Parts('body'));
  light0 = renderer.registerParts(new Parts('light0'));
  light1 = renderer.registerParts(new Parts('light1'));
  light2 = renderer.registerParts(new Parts('light2'));
  light3 = renderer.registerParts(new Parts('light3'));
  light4 = renderer.registerParts(new Parts('light4'));
  light5 = renderer.registerParts(new Parts('light5'));
  light6 = renderer.registerParts(new Parts('light6'));
  light7 = renderer.registerParts(new Parts('light7'));
  light8 = renderer.registerParts(new Parts('light8'));
  light9 = renderer.registerParts(new Parts('light9'));
  light10 = renderer.registerParts(new Parts('light10'));
}

function render(entity, pass, par3) {
  GL11.glPushMatrix();
  var light = renderer.getLightState(entity);
  if(pass == 0){
    main.render(renderer);
  }
    switch(light){
        case 0: light0.render(renderer);break;
        case 1: light1.render(renderer);break;
        case 2: light2.render(renderer);break;
        case 3: light3.render(renderer);break;
        case 4: light4.render(renderer);break;
        case 5: light5.render(renderer);break;
        case 6: light6.render(renderer);break;
        case 7: light7.render(renderer);break;
        case 8: light8.render(renderer);break;
        case 9: light9.render(renderer);break;
        case 10: light10.render(renderer);break;
    }
  else if(pass == 2){
    switch(light){
        case 0: light0.render(renderer);break;
        case 1: light1.render(renderer);break;
        case 2: light2.render(renderer);break;
        case 3: light3.render(renderer);break;
        case 4: light4.render(renderer);break;
        case 5: light5.render(renderer);break;
        case 6: light6.render(renderer);break;
        case 7: light7.render(renderer);break;
        case 8: light8.render(renderer);break;
        case 9: light9.render(renderer);break;
        case 10: light10.render(renderer);break;
    }
  }
  GL11.glPopMatrix();
}